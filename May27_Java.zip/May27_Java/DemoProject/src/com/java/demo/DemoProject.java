package com.java.demo;

public class DemoProject {

	public static void main(String[] args) {
		System.out.println("Welcome to Java Programming...");
	}
}
